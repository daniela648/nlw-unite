https://www.fronteditor.dev/nlw-unite


# HTML 

*hypertext*

*markup*
-Tag
-atributos

*linguagem*

#CSS


#JavScript
'''Js
//variaveis 
const mensagem ='oi tudo bem?'
//tipo de dados
//number
//string
//funcao
alert(mensagem)
´´´js


const participante = {
  nome: "Daniela Brito",
  email: "daniela@gmail.com",
  dataInscricao: new Date(2024, 2, 22, 19,20),
  datadecheckIn: new Date(2024, 2, 25, 22, 00),
}

let participante = [
  {
  nome: "Daniela Brito",
  email: "daniela@gmail.com",
  dataInscricao: new Date(2024, 2, 22, 19,20),
  datadecheckIn: new Date(2024, 2, 25, 22, 00),
},
]




